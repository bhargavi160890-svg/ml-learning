import os 
import gradio as gr
import numpy as np
import tensorflow as tf
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler

model = tf.keras.models.load_model("iris_mlp.keras")
iris = load_iris()
CLASSES = list(iris.target_names)
scaler = StandardScaler()
scaler.fit(iris.data)
def predict(sl,sw,pl,pw):
  values = [sl,sw,pl,pw]
  X = np.array([values],dtype=np.float32)
  x_scaled = scaler.transform(X)
  probabilities = model.predict(x_scaled)[0]
  return { CLASSES[i]:float(probabilities[i])
          for i in range(len(CLASSES)) }
  demo = gr.Interface(fn=predict,inputs=[gr.Number(value=5.1),gr.Number(value=3.5),gr.Number(value=2.1),gr.Number(value=0.2)],outputs=gr.label(num_top_classes=3,label="Predicted classes"))
  if __name__=="__main__":
    demo.launch(server_name="0.0.0.0",server_port = int(os.environ.get("PORT",8000)),)
