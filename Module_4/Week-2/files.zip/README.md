# Zodiac Sign Finder

A tiny single-page app — enter your birth date, get your zodiac sign.
Built with plain HTML/CSS/JS (no framework, no backend, no dependencies).

## Run locally
Just open `index.html` in your browser. That's it — no install step needed.

Or serve it properly (closer to how a real deploy works):
```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## Deploy (free, Week 2 of the roadmap)
1. Push this folder to a new GitHub repo
2. Go to https://vercel.com → "Add New Project" → import the repo → Deploy
   (no build settings needed, it's static HTML)
3. You'll get a live URL like `zodiac-app.vercel.app`

Netlify works the same way if you prefer that instead.

## Next steps to level this app up (optional, for later weeks)
- Add a backend (Node/Express or FastAPI) with a `GET /sign?date=YYYY-MM-DD` endpoint,
  move the logic there, call it via `fetch()` from the frontend
- Store each lookup in a database (Postgres on Neon/Supabase) as "history"
- Dockerize the backend once it exists
- Deploy backend on Render, frontend on Vercel, wire them together
